import numpy as np

def warmUpExercise():
    A = np.eye(5)
    print(A)
